extends RefCounted

const COLORS = [Color("e14b79"), Color("9c86f5"), Color("efcc7d")]
const CLOAKS = ["绯月 · 断裂", "星汐 · 流转", "圣棘 · 界定"]
const COOLDOWNS = [1.2, 1.6, 1.8]
const RELICS = {"red_echo":30, "blue_flow":30, "gold_linger":30, "tri_weave":60}
const UPGRADES = [
 {"id":"wide","title":"宽缎","description":"切割宽度增至 0.95 米。让更多敌人进入同一条断裂轨迹。","cost":60},
 {"id":"crack","title":"长痕","description":"裂痕延长至 9 秒，留出更多切换和碰撞机会。","cost":60},
 {"id":"shatter","title":"破甲余势","description":"首次破甲后，下一装甲目标额外受到 20 结构伤害。每次施法一次。","cost":60},
 {"id":"reach","title":"远结","description":"连线可达 10 米，超过 12 米才断裂。","cost":60},
 {"id":"tide","title":"伴流","description":"连接建立时，轻拉每个敌端附近的一名敌人；不额外造成伤害。","cost":60},
 {"id":"pull","title":"牵束","description":"持续牵引力增强 20%，将敌群收束到更有利的位置。","cost":60},
 {"id":"length","title":"长界","description":"边界长度上限从 6 米增加至 8 米。","cost":60},
 {"id":"linger","title":"缓界","description":"未触发的边界可等待 4.5 秒。","cost":60},
 {"id":"slow","title":"定步","description":"裁定使普通敌人减速 25%，持续 1 秒。","cost":60},
 {"id":"health","title":"补缀","description":"本局生命上限增加 20，并恢复 20 生命。","cost":60},
 {"id":"speed","title":"轻履","description":"移动速度增加 8%，更从容地绕行与绘制。","cost":60},
 {"id":"heal","title":"静息","description":"立即恢复 25 生命。","cost":60}
]

static func segment_distance(p:Vector3,a:Vector3,b:Vector3)->float:
 var v = b-a
 if v.length_squared() < 0.00001:
  return p.distance_to(a)
 var t = clampf((p-a).dot(v)/v.length_squared(),0.0,1.0)
 return p.distance_to(a+v*t)

static func flat(v:Vector3)->Vector3:
 return Vector3(v.x,0,v.z)

static func boundary_normal(a:Vector3,b:Vector3)->Vector3:
 return (b-a).normalized().cross(Vector3.UP).normalized()
